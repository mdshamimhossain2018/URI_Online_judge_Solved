#include <cstdio>

int main()
{
	double r;

	scanf("%lf", &r);
	printf("A=%.4lf\n", r*r*3.14159);

	return 0;

}