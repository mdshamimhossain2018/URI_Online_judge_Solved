#include <cstdio>

int main()
{
	int x;
	int y;

	scanf("%d", &x);
	scanf("%d", &y);
	printf("PROD = %d\n", x * y);

	return 0;
}