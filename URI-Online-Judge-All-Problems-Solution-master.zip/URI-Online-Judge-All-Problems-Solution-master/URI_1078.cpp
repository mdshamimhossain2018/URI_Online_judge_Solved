#include <cstdio>

int main()
{
	int n;

	scanf("%i", &n);

	printf("1 x %i = %i\n", n, n);
	printf("2 x %i = %i\n", n, n * 2);
	printf("3 x %i = %i\n", n, n * 3);
	printf("4 x %i = %i\n", n, n * 4);
	printf("5 x %i = %i\n", n, n * 5);
	printf("6 x %i = %i\n", n, n * 6);
	printf("7 x %i = %i\n", n, n * 7);
	printf("8 x %i = %i\n", n, n * 8);
	printf("9 x %i = %i\n", n, n * 9);
	printf("10 x %i = %i\n", n, n * 10);

	return 0;
}