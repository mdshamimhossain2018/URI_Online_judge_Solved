package URI_Problems_solution;

import java.util.Scanner;

public class URI_1001 {

	public static void main(String[] args) {
		int A, B, X;
		Scanner sc = new Scanner(System.in);
		A = sc.nextInt();
		B = sc.nextInt();
		X = A + B;
		System.out.print(X+"\n"); //Hardly advised to give \n at last

	}

}
